var krms_config ={			
	'ApiUrl' : "http://mealoop.com/merchantapp/api",	
	'DialogDefaultTitle' : "Mealoop Order Taking",
	'pushNotificationSenderid' : "946510666083",
	'APIHasKey' : "fed7b441b349bae8f146711fbd215e90"
};